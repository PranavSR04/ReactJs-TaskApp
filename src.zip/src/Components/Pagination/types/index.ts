export type CustomPaginationProps ={
    setOffset:React.Dispatch<React.SetStateAction<number>>
    offset:number
    limit:number
}