interface ThemeContextType{
	theme:boolean;
	changeTheme:()=>void;
}

export type {ThemeContextType} 