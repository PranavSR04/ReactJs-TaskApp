export const initialTasks =
[{
  "id": 1,
  "title": "Book Reviews",
  "status": "complete"
}, {
  "id": 2,
  "title": "Security Audits",
  "status": "complete"
}, {
  "id": 3,
  "title": "Wastewater Treatment",
  "status": "incomplete"
}, {
  "id": 4,
  "title": "VMware VTSP",
  "status": "complete"
}, {
  "id": 5,
  "title": "RFQ",
  "status": "complete"
}, {
  "id": 6,
  "title": "Gynecology",
  "status": "incomplete"
}, {
  "id": 7,
  "title": "TNCC",
  "status": "incomplete"
}, {
  "id": 8,
  "title": "HBSS",
  "status": "complete"
}, {
  "id": 9,
  "title": "IATA",
  "status": "incomplete"
}, {
  "id": 10,
  "title": "Volunteering",
  "status": "incomplete"
}, {
  "id": 11,
  "title": "Financial Services",
  "status": "complete"
}, {
  "id": 12,
  "title": "Major Gift Development",
  "status": "complete"
}, {
  "id": 13,
  "title": "Adobe Acrobat",
  "status": "incomplete"
}, {
  "id": 14,
  "title": "DVD",
  "status": "incomplete"
}, {
  "id": 15,
  "title": "eBay API",
  "status": "incomplete"
}]
